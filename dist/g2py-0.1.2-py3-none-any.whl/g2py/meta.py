# -*- coding: utf-8 -*-
'''
> pkg meta information
'''

__version__ = "0.1.2"
__author__ = "kevin"
